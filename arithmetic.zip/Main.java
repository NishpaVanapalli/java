/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

class Arithmetic
{
	public static void main(String args[]) {
	    int a=2,b=6,c;
	    c=a*b;
		System.out.println("Product is"+c);
		c=a+b;
		System.out.println("Sum is"+c);
		c=a-b;
		System.out.println("Difference is"+c);
		c=b/a;
		System.out.println("Division is"+c);
	}
}

